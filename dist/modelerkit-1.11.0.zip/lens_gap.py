"""Slides the rim's edge loop next to each lens onto the lens surface, along the rim's own edges, so no sliver of
rim shows between a flipped band and the lens. All or nothing per rim: the lens, flips and rim shape never change."""

import bmesh
import bpy
from mathutils.bvhtree import BVHTree

from . import explode_slider


class Refused(Exception):
    """The rim can't be processed; the message says why. Nothing was changed."""


def _lenses(rim, scene):
    """The lens meshes of the rim's own product when it sits in one, else every lens in the scene. Not the whole
    file: another scene or a second product's lens would pull the loop to the wrong place."""
    root = rim
    while root.parent:
        root = root.parent
    pool = root.children_recursive if root is not rim else scene.objects
    lenses = [o for o in pool if o is not rim and o.type == "MESH" and o.name.startswith("lens_")]
    if not lenses and root is not rim:
        lenses = [o for o in scene.objects if o is not rim and o.type == "MESH" and o.name.startswith("lens_")]
    return lenses


def _lens_trees(lenses):
    """World-space BVH per lens sheet."""
    trees = []
    for o in lenses:
        m, d = o.matrix_world, o.data
        trees.append(BVHTree.FromPolygons([m @ v.co for v in d.vertices], [tuple(p.vertices) for p in d.polygons]))
    return trees


def _nearest_lens(trees, p):
    """(index of the closest lens, distance to it)."""
    return min(((i, t.find_nearest(p)[3]) for i, t in enumerate(trees)), key=lambda r: r[1])


def _rings(edges):
    """Connected runs of these edges, as (verts, edge indices, closed)."""
    by_vert = {}
    for e in edges:
        for v in e.verts:
            by_vert.setdefault(v, []).append(e)
    seen, rings = set(), []
    for start in by_vert:
        if start in seen:
            continue
        seen.add(start)
        verts, todo = [], [start]
        while todo:
            v = todo.pop()
            verts.append(v)
            for e in by_vert[v]:
                other = e.other_vert(v)
                if other not in seen:
                    seen.add(other)
                    todo.append(other)
        rings.append((verts, {e.index for v in verts for e in by_vert[v]}, all(len(by_vert[v]) == 2 for v in verts)))
    return rings


def _candidate_edges(bm, matrix, trees, search, use_selection):
    """Edges the loops are looked for in: the Edit Mode selection when there is one, else whatever hugs a lens."""
    if use_selection:
        selected = {f for f in bm.faces if f.select}
        if selected:
            return [e for e in bm.edges if sum(f in selected for f in e.link_faces) == 1]
        edges = [e for e in bm.edges if e.select]
        if edges:
            return edges
    close = {v for v in bm.verts if _nearest_lens(trees, matrix @ v.co)[1] < search}
    return [e for e in bm.edges if e.verts[0] in close and e.verts[1] in close]


def _pick_rings(rings, matrix, trees):
    """The closest closed ring per lens. Stray pieces are ignored unless a lens has no closed ring at all."""
    best, open_lenses = {}, set()
    for ring in rings:
        verts, _, closed = ring
        hits = [_nearest_lens(trees, matrix @ v.co) for v in verts]
        lens = hits[0][0]
        if not closed:
            open_lenses.add(lens)
            continue
        mean = sum(h[1] for h in hits) / len(hits)
        if lens not in best or mean < best[lens][0]:
            best[lens] = (mean, ring)
    if open_lenses - set(best):
        raise Refused("The loop next to a lens isn't closed: raise Search Distance, or select the loop in Edit Mode")
    if not best:
        raise Refused("No edge loop next to a lens: raise Search Distance, or select the loop in Edit Mode")
    return [r for _, r in best.values()]


def _inward_faces(bm):
    """Faces pointing inward, going by Recalculate Outside. Works on a copy, so this rim's flips stay."""
    copy = bm.copy()
    before = [f.normal.copy() for f in copy.faces]
    bmesh.ops.recalc_face_normals(copy, faces=list(copy.faces))
    inward = {i for i, (b, f) in enumerate(zip(before, copy.faces)) if b.dot(f.normal) < 0}
    copy.free()
    return inward


def _forward_first(cross, band, matrix):
    """The two cross edges as (forward, back). Forward leads away from the band; without a band, to the frame front."""
    touching = [e for e in cross if any(f.index in band for f in e.link_faces)]
    if len(touching) == 1:
        back = touching[0]
        return (cross[0] if back is cross[1] else cross[1]), back
    v = cross[0].verts[0] if cross[0].verts[0] in cross[1].verts else cross[0].verts[1]
    # shortcut: assumes -Y is the frame front; upgrade if a job arrives facing elsewhere
    return tuple(sorted(cross, key=lambda e: (matrix @ e.other_vert(v).co).y))


def _plan_cut_vert(v, edge, band, lens_has_band, matrix, tree, offset):
    """A vert on a cut has one cross edge, so it slides along that edge's line: inward, or past the open end when the
    edge stops short of the lens. Both sides of the cut land on the same side of the lens, so they meet there."""
    start = matrix @ v.co
    delta = matrix @ edge.other_vert(v).co - start
    length, along = delta.length, delta.normalized()
    hits = [sign * hit[3] for sign, hit in ((1, tree.ray_cast(start, along, length)),
                                            (-1, tree.ray_cast(start, -along, length))) if hit[0] is not None]
    if not hits:
        return None
    if any(f.index in band for f in edge.link_faces):
        forward = -1
    elif lens_has_band:
        forward = 1
    else:
        forward = -1 if along.y > 0 else 1  # shortcut: assumes -Y is the frame front, same as _forward_first
    slide = min(hits, key=abs) + forward * offset
    return (edge, slide / length) if abs(slide) <= length else None


def _plan_vert(v, ring_edges, band, lens_has_band, matrix, tree, offset):
    """(cross edge to slide along, fraction of it), or None when this vert can't reach the lens."""
    cross = [e for e in v.link_edges if e.index not in ring_edges]
    if cross and offset < 1e-6 and tree.find_nearest(matrix @ v.co)[3] < 1e-6:
        return cross[0], 0.0  # already on the lens: a ray starting on the surface can miss it
    if len(cross) == 1:
        return _plan_cut_vert(v, cross[0], band, lens_has_band, matrix, tree, offset)
    if len(cross) != 2:
        return None
    start = matrix @ v.co

    def hit_along(edge):
        delta = matrix @ edge.other_vert(v).co - start
        hit = tree.ray_cast(start, delta.normalized(), delta.length)
        return (hit[3] if hit[0] is not None else None), delta.length

    forward, back = _forward_first(cross, band, matrix)
    dist, length = hit_along(forward)
    if dist is not None:
        edge, slide = forward, dist + offset
    else:
        dist, back_length = hit_along(back)
        if dist is None:
            return None
        if dist >= offset:
            edge, slide, length = back, dist - offset, back_length
        else:
            edge, slide = forward, offset - dist
    return (edge, slide / length) if slide <= length else None


def _with_other_side_of_cuts(rings, bm, matrix, trees, search):
    """A ring on a cut has a second ring along the same line: the cut's other side, which must move with it."""
    picked = {v for verts, _, _ in rings for v in verts}
    open_rings = [r for r in rings if any(e.is_boundary for e in r[0][0].link_edges)]
    if not open_rings:
        return rings
    reach = 1.5 * max(search, max(_nearest_lens(trees, matrix @ v.co)[1] for r in open_rings for v in r[0]))
    result = list(rings)
    for ring in _rings([e for e in bm.edges if e.is_boundary]):
        verts, _, closed = ring
        if closed and verts[0] not in picked and all(_nearest_lens(trees, matrix @ v.co)[1] < reach for v in verts):
            result.append(ring)
    return result


def _plan(bm, matrix, trees, search, offset, use_selection):
    """(moves as (vert, edge, fraction), snaps as (vert, local target), verts that can't reach the lens, largest
    gap)."""
    bm.faces.ensure_lookup_table()
    bm.faces.index_update()
    bm.edges.index_update()
    edges = _candidate_edges(bm, matrix, trees, search, use_selection)
    rings = _pick_rings(_rings(edges), matrix, trees)
    rings = _with_other_side_of_cuts(rings, bm, matrix, trees, search)
    band = {f.index for f in bm.faces if f.select} if use_selection else set()
    band = band or _inward_faces(bm)
    banded_lenses = {_nearest_lens(trees, matrix @ r[0][0].co)[0] for r in rings
                     if any(f.index in band for v in r[0] for f in v.link_faces)}
    inverse = matrix.inverted()
    moves, snaps, failed, gap = [], [], [], 0.0
    for verts, ring_edges, _ in rings:
        for v in verts:
            lens, dist = _nearest_lens(trees, matrix @ v.co)
            gap = max(gap, dist)
            move = _plan_vert(v, ring_edges, band, lens in banded_lenses, matrix, trees[lens], offset)
            if move:
                moves.append((v, *move))
            elif dist <= search:
                # no edge crosses the lens, as when the loop runs just outside its outline: go straight onto it
                snaps.append((v, inverse @ trees[lens].find_nearest(matrix @ v.co)[0]))
            else:
                failed.append(v)
    return moves, snaps, failed, gap


def _slide_uvs(moves, uv_layers):
    """Every UV island at a moved vert follows the slide, so a seam along the edge doesn't stretch one side."""
    for layer in uv_layers:
        new = {}
        for v, edge, t in moves:
            other = edge.other_vert(v)
            for face in edge.link_faces:
                here = next(lp for lp in face.loops if lp.vert is v)
                there = next(lp for lp in face.loops if lp.vert is other)
                old = here[layer].uv.copy()
                target = old + (there[layer].uv - old) * t  # t is negative past a cut's open end
                for lp in v.link_loops:
                    if (lp[layer].uv - old).length < 1e-5:
                        new[lp] = target
        for lp, uv in new.items():
            lp[layer].uv = uv


def _select_only(bm, verts):
    for seq in (bm.faces, bm.edges, bm.verts):
        for item in seq:
            item.select = False
    for v in verts:
        v.select = True
    bm.select_flush_mode()


def _run(op, context, apply):
    rim = context.active_object
    settings = context.scene
    if rim.name.startswith("lens_"):
        op.report({"ERROR"}, "The active object is a lens: click the rim")
        return {"CANCELLED"}
    lenses = _lenses(rim, context.scene)
    # exploded parts sit away from their rest place, so a slide would close the gap against the wrong spot
    if explode_slider.exploded([rim] + lenses):
        op.report({"ERROR"}, "Move the Explode slider back to 0 first")
        return {"CANCELLED"}
    if rim.data.shape_keys:
        op.report({"ERROR"}, "%s has shape keys: remove them first" % rim.name)
        return {"CANCELLED"}
    trees = _lens_trees(lenses)
    if not trees:
        op.report({"ERROR"}, "No lens found: lens meshes must be named lens_...")
        return {"CANCELLED"}
    editing = rim.mode == "EDIT"
    if editing:
        bm = bmesh.from_edit_mesh(rim.data)
    else:
        bm = bmesh.new()
        bm.from_mesh(rim.data)
    try:
        try:
            moves, snaps, failed, gap = _plan(bm, rim.matrix_world, trees, settings.mk_lens_gap_search,
                                       settings.mk_lens_gap_offset, editing)
        except Refused as refused:
            op.report({"ERROR"}, str(refused))
            return {"CANCELLED"}
        if failed:
            _select_only(bm, failed)
            context.tool_settings.mesh_select_mode = (True, False, False)
        elif apply:
            _slide_uvs(moves, list(bm.loops.layers.uv.values()))
            moved = sum(abs(t) * edge.calc_length() > 1e-7 for _, edge, t in moves)
            moved += sum((v.co - target).length > 1e-7 for v, target in snaps)
            for v, edge, t in moves:
                v.co = v.co + (edge.other_vert(v).co - v.co) * t
            # shortcut: snapped verts leave their UVs, fine within Search Distance; slide UVs too if stretch shows
            for v, target in snaps:
                v.co = target
        if failed or apply:
            if editing:
                bmesh.update_edit_mesh(rim.data)
            else:
                bm.to_mesh(rim.data)
                rim.data.update()
    finally:
        if not editing:
            bm.free()
    if failed:
        op.report({"ERROR"}, "%d of %d verts can't slide onto the lens along their edges. Nothing moved; they are "
                  "selected (see them in Edit Mode). Fix them by hand."
                  % (len(failed), len(failed) + len(moves) + len(snaps)))
        return {"FINISHED"}  # the selection changed: this gives Ctrl+Z a step, so it can't undo the user's last action
    if apply:
        op.report({"INFO"}, "Closed: %d verts moved, largest gap was %.4f" % (moved, gap))
    else:
        op.report({"INFO"}, "Check: %d verts can reach the lens (%d straight, not along an edge), largest gap %.4f"
                  % (len(moves) + len(snaps), len(snaps), gap))
    return {"FINISHED"}


class _RimOperator:
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == "MESH" and o.mode in {"OBJECT", "EDIT"}


class MODELERKIT_OT_check_lens_gap(_RimOperator, bpy.types.Operator):
    """Measure the gap on the active rim and show which verts can't reach the lens. Moves nothing"""
    bl_idname = "modelerkit.check_lens_gap"
    bl_label = "Check"

    def execute(self, context):
        return _run(self, context, False)


class MODELERKIT_OT_close_lens_gap(_RimOperator, bpy.types.Operator):
    """Slide the active rim's edge loop onto each lens. In Edit Mode, the selected loop or band decides which loop"""
    bl_idname = "modelerkit.close_lens_gap"
    bl_label = "Close Gap"

    def execute(self, context):
        return _run(self, context, True)


def draw(layout, context):
    layout.prop(context.scene, "mk_lens_gap_search")
    layout.prop(context.scene, "mk_lens_gap_offset")
    row = layout.row(align=True)
    row.operator(MODELERKIT_OT_check_lens_gap.bl_idname, icon="VIEWZOOM")
    row.operator(MODELERKIT_OT_close_lens_gap.bl_idname, icon="MOD_SHRINKWRAP")


classes = (MODELERKIT_OT_check_lens_gap, MODELERKIT_OT_close_lens_gap)


def register():
    bpy.types.Scene.mk_lens_gap_search = bpy.props.FloatProperty(
        name="Search Distance", default=0.02, min=0.0, step=0.1, precision=4,
        description="How close a loop must be to a lens to be found on its own. Selecting the loop ignores this")
    bpy.types.Scene.mk_lens_gap_offset = bpy.props.FloatProperty(
        name="Offset", default=0.0, min=0.0, step=0.01, precision=4,
        description="How far past the lens surface the loop lands. 0 sits exactly on the lens. Raise it only if the "
                    "line returns; too high shows the flipped band from the front")
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    del bpy.types.Scene.mk_lens_gap_offset
    del bpy.types.Scene.mk_lens_gap_search
